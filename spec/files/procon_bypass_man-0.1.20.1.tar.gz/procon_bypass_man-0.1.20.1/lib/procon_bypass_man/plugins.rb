require_relative "plugin/splatoon2/version"
require_relative "plugin/splatoon2/macro/fast_return"
require_relative "plugin/splatoon2/macro/jump_to_right_key"
require_relative "plugin/splatoon2/macro/jump_to_up_key"
require_relative "plugin/splatoon2/macro/jump_to_left_key"
require_relative "plugin/splatoon2/macro/sokuwari_for_splash_bomb"
require_relative "plugin/splatoon2/mode/guruguru"

module ProconBypassMan
  module Plugin
  end
end
