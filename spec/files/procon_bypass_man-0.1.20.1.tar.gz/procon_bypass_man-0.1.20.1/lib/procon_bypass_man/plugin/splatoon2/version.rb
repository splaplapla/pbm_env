# frozen_string_literal: true

module ProconBypassMan
  module Plugin
    module Splatoon2
      VERSION = "0.1.3"
    end
  end
end
