# SIG
```
bundle exec rbs prototype rb lib/**/*.rb > sig/main.rbs
```
