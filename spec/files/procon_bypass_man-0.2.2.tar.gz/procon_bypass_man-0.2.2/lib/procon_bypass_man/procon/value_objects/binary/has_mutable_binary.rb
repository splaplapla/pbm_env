module ProconBypassMan::Domains::HasMutableBinary
  def binary
    @binary
  end
end
