module ProconBypassMan
  module RemoteMacro
    class Task < Struct.new(:name, :uuid, :steps)
    end
  end
end
