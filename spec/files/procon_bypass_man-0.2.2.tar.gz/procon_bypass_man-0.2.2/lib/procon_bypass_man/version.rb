# frozen_string_literal: true

module ProconBypassMan
  VERSION = "0.2.1"
end
