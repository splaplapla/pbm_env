module ProconBypassMan::HasExternalApiSetting
  def server_pool
    ProconBypassMan.config.server_pool
  end
end
