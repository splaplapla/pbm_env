# frozen_string_literal: true

module ProconBypassMan
  module Plugin
    module Splatoon2
      VERSION = "0.1.5"
    end
  end
end
