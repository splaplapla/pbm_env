class ProconBypassMan::UsbDeviceController
  class << self
    def reset(cooldown: 0.5)
      [ "echo > /sys/kernel/config/usb_gadget/procon/UDC",
        "ls /sys/class/udc > /sys/kernel/config/usb_gadget/procon/UDC",
      ].each do |shell|
        system shell
        ProconBypassMan.logger.debug { "[SHELL] #{shell}" }
      end
      sleep cooldown
    end

    def init
      return if initialized?

      shell = <<~EOH
        cd /sys/kernel/config/usb_gadget/
        mkdir -p procon
        cd procon
        echo 0x057e > idVendor
        echo 0x2009 > idProduct
        echo 0x0200 > bcdDevice
        echo 0x0200 > bcdUSB
        echo 0x00 > bDeviceClass
        echo 0x00 > bDeviceSubClass
        echo 0x00 > bDeviceProtocol

        mkdir -p strings/0x409
        echo "000000000001" > strings/0x409/serialnumber
        echo "Nintendo Co., Ltd." > strings/0x409/manufacturer
        echo "Pro Controller" > strings/0x409/product

        mkdir -p configs/c.1/strings/0x409
        echo "Nintendo Switch Pro Controller" > configs/c.1/strings/0x409/configuration
        echo 500 > configs/c.1/MaxPower
        echo 0xa0 > configs/c.1/bmAttributes

        mkdir -p functions/hid.usb0
        echo 0 > functions/hid.usb0/protocol
        echo 0 > functions/hid.usb0/subclass
        echo 64 > functions/hid.usb0/report_length
        echo 050115000904A1018530050105091901290A150025017501950A5500650081020509190B290E150025017501950481027501950281030B01000100A1000B300001000B310001000B320001000B35000100150027FFFF0000751095048102C00B39000100150025073500463B0165147504950181020509190F2912150025017501950481027508953481030600FF852109017508953F8103858109027508953F8103850109037508953F9183851009047508953F9183858009057508953F9183858209067508953F9183C0 | xxd -r -ps > functions/hid.usb0/report_desc

        ln -s functions/hid.usb0 configs/c.1/
        ls /sys/class/udc > UDC
      EOH

      `bash -c '#{shell}'`
      sleep(1)
    end

    def initialized?
      Dir.exist?("/sys/kernel/config/usb_gadget/procon")
    end
  end
end
