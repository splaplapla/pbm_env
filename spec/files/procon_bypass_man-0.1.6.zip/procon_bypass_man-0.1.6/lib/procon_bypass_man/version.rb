# frozen_string_literal: true

module ProconBypassMan
  VERSION = "0.1.6"
end
